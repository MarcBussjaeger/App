package Enums;

public enum Gen {
	female, male
}
